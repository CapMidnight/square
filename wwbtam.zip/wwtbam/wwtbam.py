score=0
koll=0
f=open(u'C:\wwtbam\db.txt','r')
while True:
	vopros=f.readline().strip()
	if(not vopros):
		break
	otvet1=f.readline().strip()
	otvet2=f.readline().strip()
	kod=f.readline().strip()
	print('1 '+otvet1)
	print('2 '+otvet2)
	k=str(input('Введите номер правильного ответа и нажмие Enter'))
	koll=koll+1
	if(k==kod):
		 score=score+1
print('Вы оветили на '+str(score)+' из '+str(koll)+'вопросов')
